# Documentation Index — Spec Classifier (Dell + Cisco CCW + HPE)

## Structure

| Folder | Purpose |
|---|---|
| `docs/product/` | **Normative.** Architecture, baseline, data pipeline. Must match current code. |
| `docs/user/` | **Normative.** User guide, CLI reference. How to operate the tool. |
| `docs/schemas/` | **Normative.** Data contracts: field specs for all output formats. |
| `docs/rules/` | **Normative.** Rules authoring guide. |
| `docs/dev/` | **Normative.** Contributing, testing, operational notes. |
| `docs/taxonomy/` | **Normative.** Source of truth for controlled vocabularies (e.g., hw_type). |

## Key Documents

| Document | What it answers |
|---|---|
| `README.md` | How do I install and run this? |
| `docs/user/USER_GUIDE.md` | How do I interpret the output? |
| `docs/user/CLI_CONFIG_REFERENCE.md` | What are all CLI options and config keys? |
| `docs/user/RUN_PATHS_AND_IO_LAYOUT.md` | Where do inputs/outputs go? Default paths (Desktop INPUT/OUTPUT), vendor run layout, no TEMP. |
| `docs/schemas/DATA_CONTRACTS.md` | What are the exact output schemas? |
| `docs/rules/RULES_AUTHORING_GUIDE.md` | How do I add or change a rule safely? |
| `docs/dev/NEW_VENDOR_GUIDE.md` | How do I add a new vendor (adapter, rules, tests)? |
| `docs/dev/ONE_BUTTON_RUN.md` | How do I run tests and batch with one script (Windows)? |
| `docs/dev/TESTING_GUIDE.md` | How do I run tests and update golden? |
| `docs/dev/CONTRIBUTING.md` | How do I work in this repo? |
| `docs/dev/OPERATIONAL_NOTES.md` | How do I run batch jobs and manage artifacts? |
| `docs/product/TECHNICAL_OVERVIEW.md` | How does the pipeline work internally? |
| `CHANGELOG.md` | What changed in each version? |
| `docs/taxonomy/hw_type_taxonomy.md` | What are the allowed hw_type values and the exact meaning/boundaries? |
| `batch_audit.py` | How do I run post-pipeline rule checks (E1–E18) and LLM verification across all vendor outputs? |
| `cluster_audit.py` | How do I cluster unclassified/UNKNOWN rows to discover new rules? |

| `CLAUDE.md` | Project context for Cowork / Claude Desktop sessions |
| `prompts/README.md` | Prompt library — step templates for dev cycle |

## Conventions

- **Normative docs** (`product/`, `user/`, `schemas/`, `rules/`, `dev/`, `taxonomy/`): must stay in sync
  with code. Update docs in the same commit as any behavior change.
