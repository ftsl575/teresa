# prompts/ — Библиотека промптов Teresa

Готовые промпты для каждого шага цикла разработки.
Открывай нужный файл, копируй промпт — не нужно грузить steps_plan_for_FTSL_v2.txt.

---

## Режим работы

**Claude.ai (окна):** загружай `teresa.zip` + `OUTPUT.rar` как вложения.
**Cowork (этот режим):** архивы не нужны — Claude имеет прямой доступ к папкам репо, INPUT и OUTPUT. Просто скажи: _"запусти шаг 1A"_ — и всё.
Правило R1 ("каждый шаг = отдельное окно") в Cowork **не применяется** — все шаги можно выполнять в одной сессии.

---

## Структура

| Файл | Когда использовать |
|---|---|
| `01_PRE-CHECK.md` | Перед любыми изменениями — зафиксировать baseline |
| `02_MASTER-PLAN.md` | Сгенерировать план для Cursor (вариант A=новая фича, B=fix FAIL) |
| `03_CURSOR-IMPLEMENT.md` | Промпт для вставки в Cursor |
| `04_POST-CHECK.md` | После реализации — собрать факты |
| `05_AUDIT-1A-1G.md` | Полный аудит (6 окон Claude + финальный вердикт) |
| `06_BATCH-AUDIT-MASTER-PLAN.md` | Анализ audit_report.json + план правок YAML |
| `07_DOC-UPDATE-MASTER-PLAN.md` | Обновление документации после цикла фиксов |
| `08_CHATGPT-SYSTEM-PROMPTS.md` | System prompts для ChatGPT (3 варианта) |

---

## Быстрый сценарий: маленькая правка YAML

```
01_PRE-CHECK → 06_BATCH-AUDIT-MASTER-PLAN → 03_CURSOR-IMPLEMENT → 04_POST-CHECK
```

## Быстрый сценарий: новая фича

```
01_PRE-CHECK → 02_MASTER-PLAN (A) → 03_CURSOR-IMPLEMENT → 04_POST-CHECK → (опц.) 05_AUDIT-1G
```

## Полный цикл: новый вендор / большой рефакторинг

```
01 → 02A → 03 → 04 → 05 (1A–1G) → 07_DOC-UPDATE
```

## После FAIL аудита

```
02B (fix) → 03 → 04 → 05_1G → 07_DOC-UPDATE
```
